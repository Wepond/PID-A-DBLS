clear all;
clc;
% addpath regression;
addpath bls;
addpath FBLS;
% load airfoilselfnoise;
% load Combinedcyclepowerplant;
% load Geographical;
load Concretecompressivestrength;

P=[p_train;p_test];
T=[t_train;t_test];
fried=[P,T];
clear p_train;
clear p_test;
clear t_train;
clear t_test;
[M,N]=size(fried);
K=10;
data=fried;
selec=randperm(M);
selec=selec';
data_randn=data(selec,:);
indices=crossvalind('Kfold',data_randn(1:M,N),K);
NumberFeatureNode=20;
% NumberEnhanceNode=10;

s=0.01;
C=21000;
N1=5;
N2=5;
% N3=10;

NumRule=2; %1:1:20                 %searching range for fuzzy rules  per fuzzy subsystem
NumFuzz=25;%1:1:20              %searching range for number of fuzzy subsystems
% NumEnhan=10; %1:1:20    %searching range for enhancement nodes
for j=2:2:10
WeightEnhan=rand(NumFuzz*NumRule+1,j); %%Iinitializing  weights connecting fuzzy subsystems with enhancement layer

for i=1:K
    test = (indices == i);
    train = ~test;
    p_train=data_randn(train,1:end-1);
    t_train=data_randn(train,end);
    p_test=data_randn(test,1:end-1);
    t_test=data_randn(test,end);
    
    [pn_train,inputps] = mapminmax(p_train',0,1);
    pn_train = pn_train';
    pn_test = mapminmax('apply',p_test',inputps);
    pn_test = pn_test';

    [tn_train,outputps] = mapminmax(t_train',0,1);
    tn_train = tn_train';
    tn_test = mapminmax('apply',t_test',outputps);
    tn_test = tn_test';
    
    testmean=repmat(mean(t_test),1,length(t_test));
    testmean=testmean';
    
    %BLS
    [TrainingAccuracyBLS,TestingAccuracyBLS,Training_timeBLS,Testing_timeBLS,output1] = bls_train(pn_train,tn_train,pn_test,tn_test,s,C,N1,N2,j);
    clear TrainingAccuracyBLS;
    clear TestingAccuracyBLS;
    clear Training_timeBLS;
    clear Testing_timeBLS;
    BLSoutput = mapminmax('reverse',output1,outputps);
    BLSRMSE(i)=sqrt(mse(t_test - BLSoutput));
    BLSMEAN=repmat(mean(BLSoutput),1,length(BLSoutput));
    BLSMEAN=BLSMEAN';
    BLSRSD(i)=sqrt(mse(BLSoutput-BLSMEAN))/sqrt(mse(t_test - testmean));
    BLSMPE(i)=mean(abs((BLSoutput - t_test)./t_test));
    clear output1;
    clear BLSoutput;
    clear BLSMEAN;
    
    %FBLS
    for qq=1:NumFuzz
        alpha=rand(size(pn_train,2),NumRule);
        Alpha{qq}=alpha;
    end  %generating coefficients of the then part of fuzzy rules for each fuzzy system
    clear qq;
    [output2,Training_timeFBLS,Testing_timeFBLS,TrainingFBLS,TestingFBLS]  = fbls_train(pn_train,tn_train,pn_test,tn_test,Alpha,WeightEnhan,s,C,NumRule,NumFuzz);
    clear Training_timeFBLS;
    clear Testing_timeFBLS;
    clear TrainingFBLS;
    clear TestingFBLS;
    clear Alpha;
    FBLSoutput = mapminmax('reverse',output2,outputps);
    FBLSRMSE(i)=sqrt(mse(t_test - FBLSoutput));
    FBLSMEAN=repmat(mean(FBLSoutput),1,length(FBLSoutput));
    FBLSMEAN=FBLSMEAN';
    FBLSRSD(i)=sqrt(mse(FBLSoutput-FBLSMEAN))/sqrt(mse(t_test - testmean));
    FBLSMPE(i)=mean(abs((FBLSoutput - t_test)./t_test));
    clear output2;
    clear FBLSoutput;
    clear FBLSMEAN;
    
    %ADAMPIDDBLS
    output3 = ADAMPIDDBLS(pn_train,tn_train,pn_test,NumberFeatureNode,j);
    MSRADMMPIDDBLSoutput = mapminmax('reverse',output3,outputps);
    MSRADMMPIDDBLSRMSE(i)=sqrt(mse(t_test - MSRADMMPIDDBLSoutput));
    MSRADMMPIDDBLSMEAN=repmat(mean(MSRADMMPIDDBLSoutput),1,length(MSRADMMPIDDBLSoutput));
    MSRADMMPIDDBLSMEAN=MSRADMMPIDDBLSMEAN';
    MSRADMMPIDDBLSRSD(i)=sqrt(mse(MSRADMMPIDDBLSoutput-MSRADMMPIDDBLSMEAN))/sqrt(mse(t_test - testmean));
    MSRADMMPIDDBLSMPE(i)=mean(abs((MSRADMMPIDDBLSoutput - t_test)./t_test));
    clear output3;
    clear MSRADMMPIDDBLSoutput;
    clear MSRADMMPIDDBLSMEAN;
    
    clear pn_train;
    clear tn_train;
    clear pn_test;
    
    clear tn_test;
    clear p_train;
    clear t_train;
    clear p_test;
    clear t_test;
    clear testmean;
    
end
BLSRMSE1(j/2)=sum(BLSRMSE)/K;
BLSRSD1(j/2)=sum(BLSRSD)/K;
BLSMPE1(j/2)=sum(BLSMPE)/K;
clear BLSRMSE;
clear BLSRSD;
clear BLSMPE;

FBLSRMSE1(j/2)=sum(FBLSRMSE)/K;
FBLSRSD1(j/2)=sum(FBLSRSD)/K;
FBLSMPE1(j/2)=sum(FBLSMPE)/K;
clear FBLSRMSE;
clear FBLSRSD;
clear FBLSMPE;

MSRADMMPIDDBLSRMSE1(j/2)=sum(MSRADMMPIDDBLSRMSE)/K;
MSRADMMPIDDBLSRSD1(j/2)=sum(MSRADMMPIDDBLSRSD)/K;
MSRADMMPIDDBLSMPE1(j/2)=sum(MSRADMMPIDDBLSMPE)/K;
clear MSRADMMPIDDBLSRMSE;
clear MSRADMMPIDDBLSRSD;
clear MSRADMMPIDDBLSMPE;
end

subplot(311)
plot(2:2:10,BLSRMSE1,'-gs',2:2:10,FBLSRMSE1,'-rd',2:2:10,MSRADMMPIDDBLSRMSE1,'-bp');
legend('BLS','FBLS','PID-A-DBLS');
grid on;
xlabel('Number of enhancement nodes');
ylabel('RMSE');
subplot(312)
plot(2:2:10,BLSMPE1,'-gs',2:2:10,FBLSMPE1,'-rd',2:2:10,MSRADMMPIDDBLSMPE1,'-bp');
legend('BLS','FBLS','PID-A-DBLS');
grid on;
xlabel('Number of enhancement nodes');
ylabel('MPE');
subplot(313)
plot(2:2:10,BLSRSD1,'-gs',2:2:10,FBLSRSD1,'-rd',2:2:10,MSRADMMPIDDBLSRSD1,'-bp');
legend('BLS','FBLS','PID-A-DBLS');
grid on;
xlabel('Number of enhancement nodes');
ylabel('RSD');