function [y] = ADAMPIDDBLS(train_x,train_y,test_x,NumberFeatureNode,NumberEnhanceNode)

InputWeightFeatureNode=rand(size(train_x',1),NumberFeatureNode)*2-1;
BiasFeatureNode=rand(1,NumberFeatureNode)*2-1;
BiasFeatureNodeMatrix=repmat(BiasFeatureNode',1,size(train_x',2));
OutputFeatureNodeMatrix=tansig(InputWeightFeatureNode'*train_x'+BiasFeatureNodeMatrix);

InputWeightEnhanceNode=rand(size(OutputFeatureNodeMatrix,1),NumberEnhanceNode)*2-1;
BiasEnhanceNode=rand(1,NumberEnhanceNode)*2-1;
BiasEnhanceNodeMatrix=repmat(BiasEnhanceNode',1,size(OutputFeatureNodeMatrix,2));
OutputEnhanceNodeMatrix=tansig(InputWeightEnhanceNode'*OutputFeatureNodeMatrix+BiasEnhanceNodeMatrix);

n1=size(OutputFeatureNodeMatrix,1);
for i=1:n1-1
    xishu(i,1)=(mse(OutputFeatureNodeMatrix(i,:)))/(1+sqrt(mse(OutputFeatureNodeMatrix(i,:))));
end
clear i;
for i=1:n1-1
    q=i+1;
    for j=q:n1
        OutputFeatureNodeMatrix(j,:)=xishu(i,1)*OutputFeatureNodeMatrix(i,:)+OutputFeatureNodeMatrix(j,:);
    end
end
clear n1;
clear i;
clear q;
clear j;
clear xishu;

n1=size(OutputEnhanceNodeMatrix,1);
for i=1:n1-1
    xishu(i,1)=(mse(OutputEnhanceNodeMatrix(i,:)))/(1+sqrt(mse(OutputEnhanceNodeMatrix(i,:))));
end
clear i;
for i=1:n1-1
    q=i+1;
    for j=q:n1
        OutputEnhanceNodeMatrix(j,:)=xishu(i,1)*OutputEnhanceNodeMatrix(i,:)+OutputEnhanceNodeMatrix(j,:);
    end
end
clear n1;
clear i;
clear q;
clear j;
clear xishu;

kp=0.000011;
ki=0.000002;
kd=0.002;

e=zeros(NumberFeatureNode,1);
betaFeatureNode=zeros(NumberFeatureNode,1);
e(1,1)=sqrt(mse(train_y));
error=train_y;
temp1=0;
eck1=0;
eck2=0;
for i=1:NumberFeatureNode
    P=kp*(e(i,1)-eck1);
    I=ki*e(i,1);
    D=kd*(e(i,1)-2*eck1+eck2);
    u=P+I+D;
    betaFeatureNode(i,1)=temp1+u;
    error=error-betaFeatureNode(i,1)*OutputFeatureNodeMatrix(i,:)';
    e(i+1,1)=sqrt(mse(error));
    temp1=betaFeatureNode(i,1);
    clear u;
    eck2=eck1;
    eck1=e(i,1);
end
% clear temp;
clear temp1;
clear eck1;
clear eck2;
% OutputWeight=[OutputWeightADAM;betaEnhanceNode];
yyy1=train_y - OutputFeatureNodeMatrix'*betaFeatureNode;
x00=zeros(NumberEnhanceNode,1);
[OutputWeightADAM, outAdam] = ADAM(x00,OutputEnhanceNodeMatrix',yyy1);
clear outAdam;
clear yyy1;
clear x00;

OutputWeight=[betaFeatureNode;OutputWeightADAM];

BiasFeatureNodeMatrixtesting=repmat(BiasFeatureNode',1,size(test_x',2));
OutputFeatureNodeMatrixtesting=tansig(InputWeightFeatureNode'*test_x'+BiasFeatureNodeMatrixtesting);

BiasEnhanceNodeMatrixtesting=repmat(BiasEnhanceNode',1,size(OutputFeatureNodeMatrixtesting,2));
OutputEnhanceNodeMatrixtesting=tansig(InputWeightEnhanceNode'*OutputFeatureNodeMatrixtesting+BiasEnhanceNodeMatrixtesting);

n1=size(OutputFeatureNodeMatrixtesting,1);
for i=1:n1-1
    xishu(i,1)=(mse(OutputFeatureNodeMatrixtesting(i,:)))/(1+sqrt(mse(OutputFeatureNodeMatrixtesting(i,:))));
end
clear i;
for i=1:n1-1
    q=i+1;
    for j=q:n1
        OutputFeatureNodeMatrixtesting(j,:)=xishu(i,1)*OutputFeatureNodeMatrixtesting(i,:)+OutputFeatureNodeMatrixtesting(j,:);
    end
end
clear n1;
clear i;
clear q;
clear j;
clear xishu;

n1=size(OutputEnhanceNodeMatrixtesting,1);
for i=1:n1-1
    xishu(i,1)=(mse(OutputEnhanceNodeMatrixtesting(i,:)))/(1+sqrt(mse(OutputEnhanceNodeMatrixtesting(i,:))));
end
clear i;
for i=1:n1-1
    q=i+1;
    for j=q:n1
        OutputEnhanceNodeMatrixtesting(j,:)=xishu(i,1)*OutputEnhanceNodeMatrixtesting(i,:)+OutputEnhanceNodeMatrixtesting(j,:);
    end
end
clear n1;
clear i;
clear q;
clear j;
clear xishu;
OutputBLStesting=[OutputFeatureNodeMatrixtesting;OutputEnhanceNodeMatrixtesting]';
y=OutputBLStesting*OutputWeight;
end