clear; 
warning off all;
format compact;
load mnist;

%%%%%%%%%%%%%%%the samples from the data are normalized and the lable data
%%%%%%%%%%%%%%%train_y and test_y are reset as N*C matrices%%%%%%%%%%%%%%
train_x = double(train_x/255);
train_y = double(train_y);
% test_x = double(train_x/255);
% test_y = double(train_y);
test_x = double(test_x/255);
test_y = double(test_y);
% train_y=(train_y-1)*2+1;
% test_y=(test_y-1)*2+1;